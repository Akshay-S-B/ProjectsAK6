package Collections.EMS;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;

public class console {
    private List<emp> employees;

    public console() {
        this.employees = new ArrayList<>();
    }

    public int showOptions() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Employee Management System:");
        System.out.println("1. Read All Employees");
        System.out.println("2. Add Employee");
        System.out.println("3. Update Employee");
        System.out.println("4. Delete Employee");
        System.out.println("5. Exit");

        System.out.print("Enter your choice: ");
        int choice = sc.nextInt();
        return choice;
    }

    public void run() throws IOException {
        boolean exit = false;
        while (!exit) {
            int choice = showOptions();
            switch (choice) {
                case 1:
                    readAllEmployees();
                    break;
                case 2:
                    addEmployee();
                    break;
                case 3:
                    updateEmployee();
                    break;
                case 4:
                    deleteEmployee();
                    break;
                case 5:
                    exit = true;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private void readAllEmployees() {
        System.out.println("List of Employees:");
        for (emp e : employees) {
            System.out.println(e.toString());
        }
    }

    private void addEmployee() throws IOException {
        emp newEmployee = acceptEmp();
        employees.add(newEmployee);
        System.out.println("Employee added successfully.");
    }

    private void updateEmployee() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter the ID of the employee to update: ");
        String id = br.readLine();

        boolean found = false;
        for (emp e : employees) {
            if (e.getId().equals(id)) {
                System.out.print("Enter new name: ");
                e.setName(br.readLine());

                System.out.print("Enter new position: ");
                e.setPosition(br.readLine());

                System.out.print("Enter new salary: ");
                e.setSalary(Double.parseDouble(br.readLine()));

                System.out.print("Enter new age: ");
                e.setAge(Integer.parseInt(br.readLine()));

                System.out.println("Employee updated successfully.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Employee not found with ID: " + id);
        }
    }

    private void deleteEmployee() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter the ID of the employee to delete: ");
        String id = br.readLine();

        emp toRemove = null;
        for (emp e : employees) {
            if (e.getId().equals(id)) {
                toRemove = e;
                break;
            }
        }

        if (toRemove != null) {
            employees.remove(toRemove);
            System.out.println("Employee deleted successfully.");
        } else {
            System.out.println("Employee not found with ID: " + id);
        }
    }

    public emp acceptEmp() throws IOException {
        InputStreamReader ir = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(ir);

        System.out.print("Enter the employee name: ");
        String name = br.readLine();

        System.out.print("Enter the employee position: ");
        String pos = br.readLine();

        System.out.print("Enter the salary: ");
        double salary = Double.parseDouble(br.readLine());

        System.out.print("Enter the age: ");
        int age = Integer.parseInt(br.readLine());

        String id = UUID.randomUUID().toString();

        return new emp(id, name, pos, salary, age);
    }
}
