// Node class represents each node in the linked list
class Node {
    int data; // data stored in the node
    Node next; // reference to the next node in the list

    // Constructor to initialize the node with a given data
    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

// LinkedList class represents the linked list and its operations
class LinkedList {
    private Node head; // head node of the linked list

    // Constructor to initialize an empty linked list
    public LinkedList() {
        this.head = null;
    }

    // Method to insert a new node at the beginning of the linked list
    public void insertAtBeginning(int data) {
        Node newNode = new Node(data); // create a new node

        // Set the new node's next pointer to the current head
        newNode.next = head;

        // Set the head to point to the new node
        head = newNode;
    }

    // Method to print all the elements of the linked list
    public void display() {
        Node current = head; // start from the head node
        System.out.print("Linked List: ");
        while (current != null) {
            System.out.print(current.data + " "); // print current node's data
            current = current.next; // move to the next node
        }
        System.out.println();
    }
}

// Main class to demonstrate the usage of LinkedList
public class Main {
    public static void main(String[] args) {
        LinkedList myList = new LinkedList(); // create an instance of
