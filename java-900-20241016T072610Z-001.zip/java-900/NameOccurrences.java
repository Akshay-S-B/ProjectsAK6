import java.util.HashMap;
import java.util.Map;

public class NameOccurrences {
    
    public static void main(String[] args) {
        // Create a list of names
        String[] names = {"Alice", "Bob", "Charlie", "Alice", "David", "Alice", "Bob", "Alice"};
        
        // Create a HashMap to store name occurrences
        Map<String, Integer> nameCount = new HashMap<>();
        
        // Count occurrences of each name
        for (String name : names) {
            if (nameCount.containsKey(name)) {
                // If name is already in map, increment its count
                nameCount.put(name, nameCount.get(name) + 1);
            } else {
                // If name is not in map, add it with count 1
                nameCount.put(name, 1);
            }
        }
        
        // Print the occurrences of each name
        System.out.println("Occurrences of each name:");
        for (Map.Entry<String, Integer> entry : nameCount.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
