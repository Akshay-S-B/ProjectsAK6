document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const errorMsg = document.getElementById('error-msg');

    loginForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent form submission

        // Get input values
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();

        // Simple validation
        if (username === '' || password === '') {
            errorMsg.textContent = 'Please enter both username and password.';
        } else {
            // Perform login logic (dummy example)
            if (username === 'admin' && password === 'password') {
                alert('Login successful!'); // Replace with actual login logic
                // Redirect to dashboard page
                window.location.href = 'dashboard.html';
            } else {
                errorMsg.textContent = 'Invalid username or password. Please try again.';
            }
        }
    });
});
