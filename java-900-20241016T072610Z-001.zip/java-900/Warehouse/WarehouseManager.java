import java.util.Scanner;

public class WarehouseManager {
    private static List<Item> warehouseItems = new ArrayList<>();
    private static Cart cart = new Cart();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        initializeWarehouse();

        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    displayWarehouseItems();
                    break;
                case 2:
                    addToCart();
                    break;
                case 3:
                    viewCart();
                    break;
                case 4:
                    checkout();
                    break;
                case 5:
                    System.out.println("Thank you for using the Warehouse Manager!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        } while (choice != 5);
    }

    private static void displayMenu() {
        System.out.println("\n=== Warehouse Manager Menu ===");
        System.out.println("1. View Warehouse Items");
        System.out.println("2. Add Item to Cart");
        System.out.println("3. View Cart");
        System.out.println("4. Checkout");
        System.out.println("5. Exit");
    }

    private static void initializeWarehouse() {
        // Initialize warehouse with some items
        warehouseItems.add(new Item(1, 29.99, "Wireless Mouse", "Logitech M510", 10));
        warehouseItems.add(new Item(2, 499.99, "Smartphone", "Samsung Galaxy S20", 5));
        warehouseItems.add(new Item(3, 599.99, "Laptop", "Dell XPS 13", 3));
        warehouseItems.add(new Item(4, 149.99, "Bluetooth Speaker", "JBL Flip 5", 7));
    }

    private static void displayWarehouseItems() {
        System.out.println("\n=== Items in Warehouse ===");
        for (Item item : warehouseItems) {
            System.out.println(item);
        }
    }

    private static void addToCart() {
        System.out.println("\n=== Add Item to Cart ===");
        displayWarehouseItems();
        System.out.print("Enter the Item ID to add to cart: ");
        int itemId = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        Item selectedItem = null;
        for (Item item : warehouseItems) {
            if (item.getItemId() == itemId) {
                selectedItem = item;
                break;
            }
        }
        if (selectedItem == null) {
            System.out.println("Item with ID " + itemId + " not found in warehouse.");
        } else {
            if (selectedItem.getQuantity() > 0) {
                cart.addItem(selectedItem);
                selectedItem.setQuantity(selectedItem.getQuantity() - 1);
                System.out.println(selectedItem.getTitle() + " added to cart.");
            } else {
                System.out.println("Sorry, " + selectedItem.getTitle() + " is out of stock.");
            }
        }
    }

    private static void viewCart() {
        System.out.println("\n=== Items in Cart ===");
        List<Item> cartItems = cart.getItems();
        if (cartItems.isEmpty()) {
            System.out.println("Cart is empty.");
        } else {
            for (Item item : cartItems) {
                System.out.println(item.getTitle() + " - $" + item.getPrice());
            }
            System.out.println("Total: $" + cart.calculateTotal());
        }
    }

    private static void checkout() {
        System.out.println("\n=== Checkout ===");
        if (cart.getItems().isEmpty()) {
            System.out.println("Cart is empty. Nothing to checkout.");
        } else {
            double total = cart.calculateTotal();
            System.out.println("Total amount to pay: $" + total);
            System.out.println("Thank you for your purchase!");
            cart.clearCart();
        }
    }
}