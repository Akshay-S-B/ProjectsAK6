public class th {
public static void printHelloworld() 
for (int 1 = 0; 1 < 10; i++) {System.out.println(x: "hello world");
}Run | Debug
public static void main(String[l args) throws InterruptedException [Thread th = new Thread(() →> printHelloworld());Thread th2 = new Thread(() → System.out printin(2 + 2));
// System-out.println(3 + 3);Thread. sleep(millis:3000); // wait th. start():/1 th. join():th2.start
