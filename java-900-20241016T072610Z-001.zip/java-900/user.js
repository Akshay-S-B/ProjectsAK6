let user = {
    name: "Akshay",
    email: "akshay@example.com",
    age: 25
};

function changeName(newName) {
    user.name = newName;
}

function updateEmail(newEmail) {
    user.email = newEmail;
}

function calculateBirthYear() {
    let currentYear = new Date().getFullYear();
    return currentYear - user.age;
}

console.log(user);
changeName("Bolmal");
console.log(user);
updateEmail("bolmal@example.com");
console.log(user);
console.log(`Birth Year: ${calculateBirthYear()}`);
