document.getElementById('emailForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const email = document.getElementById('email').value;
    const message = document.getElementById('message');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
        message.textContent = 'Please enter a valid email address.';
    } else {
        message.textContent = '';
        // Submit the form or perform any other desired action
        alert('Email is valid!');
    }
});
