/**
 * variables
 */
public class variables {
    public static void main(String[] args) {
        // variables
        int a = 5;
        double d = 34.567894;
        char ch = 'r';
        String str = "Aaryan is a Trainer";

        a = 6;
        System.out.println("The value of a is: " + a);
        
        // constant --> value should not change
        final int b = 10;
        System.out.println(b);
    }
}