fun main() {
    // Define two numbers
    val number1 = 10
    val number2 = 20

    // Add the numbers
    val sum = number1 + number2

    // Print the result
    println("The sum of $number1 and $number2 is $sum")
}
