import java.util.Scanner

fun main() {
    // Create a Scanner object to read input
    val reader = Scanner(System.`in`)

    // Prompt the user to enter the first string
    print("Enter the first string: ")
    val string1 = reader.nextLine()

    // Prompt the user to enter the second string
    print("Enter the second string: ")
    val string2 = reader.nextLine()

    // Concatenate the strings
    val result = string1 + " " + string2

    // Print the result
    println("The concatenated string is: $result")
}
