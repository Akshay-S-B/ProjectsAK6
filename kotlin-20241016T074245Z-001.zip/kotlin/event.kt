data class Event(val name: String, val date: String, val attendeeCount: Int)

fun createEvent(name: String, date: String, attendeeCount: Int): Event {
    return Event(name, date, attendeeCount)
}

fun main() {
    val event = createEvent("Kotlin Meetup", "2024-07-21", 100)
    when {
        event.attendeeCount > 50 -> println("Large event: ${event.name}")
        event.attendeeCount in 20..50 -> println("Medium event: ${event.name}")
        else -> println("Small event: ${event.name}")
    }
}
