fun main() {
    val eventName = "Kotlin Workshop"
    val date = "2024-07-20"
    println("Welcome to the $eventName on $date!")
}
