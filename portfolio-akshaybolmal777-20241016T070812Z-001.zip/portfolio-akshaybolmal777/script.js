document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('contactForm');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        const name = document.getElementById('name').value.trim();
        const email = document.getElementById('email').value.trim();
        const message = document.getElementById('message').value.trim();

        // Validate Name
        if (name === '') {
            alert('Please enter your name.');
            return;
        }

        // Validate Email
        if (email === '') {
            alert('Please enter your email.');
            return;
        } else if (!isValidEmail(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        // Validate Message
        if (message === '') {
            alert('Please enter your message.');
            return;
        }

        // Display the submitted data on the page
        displaySubmissionResult(name, email, message);

        // Optionally, clear the form
        form.reset();
    });

    // Helper function to validate email format
    function isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    // Function to display the submission result
    function displaySubmissionResult(name, email, message) {
        const resultContainer = document.getElementById('submissionResult');
        resultContainer.innerHTML = `
            <h2>Submission Result</h2>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Message:</strong> ${message}</p>
        `;
    }
});
