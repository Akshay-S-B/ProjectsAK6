const express = require('express');
const app = express();
const db = require('./db/db');
const bodyParser = require('body-parser');
const port = process.env.PORT || 3000;

app.use(bodyParser.json());

app.get('/', (req, res) => res.send('Hello World!'));

// Login
app.post("/login", async (req, res) => {
    const { email, pass } = req.body;
    try {
        const result = await db.Auth.find({ email, pass });
        if (result.length === 1) {
            res.json({ msg: "Login successful", status: 200 });
        } else {
            res.status(400).json({ msg: "Login failed", status: 400 });
        }
    } catch (error) {
        res.status(500).json({ msg: "Internal server error", error });
    }
});

// Register
app.post("/register", async (req, res) => {
    const body = req.body;
    try {
        const result = await db.Auth.create(body);
        res.status(201).json({ msg: "User registered successfully", status: 201 });
    } catch (error) {
        res.status(400).json({ msg: "User registration failed", error });
    }
});

// File a Claim
app.post("/file-claim", async (req, res) => {
    const claimData = req.body;
   
    // Log the incoming request data for debugging
    console.log("Received claim data:", claimData);
   
    if (!claimData.userId || !claimData.description || !claimData.photoUrl) {
        return res.status(400).json({ msg: "Invalid data", status: 400 });
    }

    try {
        const result = await db.Claim.create(claimData);
        res.status(201).json({ msg: "Claim filed successfully", status: 201, claimId: result._id });
    } catch (error) {
        res.status(400).json({ msg: "Claim filing failed", error });
    }
});

// Get Claim Status
app.get("/claim-status/:claimId", async (req, res) => {
    const { claimId } = req.params;
    try {
        const claim = await db.Claim.findById(claimId);
        if (claim) {
            res.json({ status: claim.status });
        } else {
            res.status(404).json({ msg: "Claim not found", status: 404 });
        }
    } catch (error) {
        res.status(400).json({ msg: "Error fetching claim status", status: 400, error });
    }
});

// Get All Claims
app.get("/claims", async (req, res) => {
    try {
        const claims = await db.Claim.find();
        res.json(claims);
    } catch (error) {
        res.status(500).json({ msg: "Error fetching claims", error });
    }
});

app.listen(port, () => console.log(`App listening on port ${port}!`));

